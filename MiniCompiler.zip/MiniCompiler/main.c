#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#define MAX_VARS 26

typedef enum {
    TOKEN_NUMBER,
    TOKEN_PLUS,
    TOKEN_MINUS,
    TOKEN_MULTIPLY,
    TOKEN_DIVIDE,
    TOKEN_LPAREN,
    TOKEN_RPAREN,
    TOKEN_IDENTIFIER,
    TOKEN_ASSIGN,
    TOKEN_END,
    TOKEN_INVALID
} TokenType;

typedef struct {
    TokenType type;
    double value;
    char identifier;
} Token;

char *input;
size_t pos = 0;
double variables[MAX_VARS] = {0};
Token current_token;

Token get_next_token() {
    while (input[pos] != '\0') {
        if (isspace(input[pos])) {
            pos++;
            continue;
        }

        if (isdigit(input[pos])) {
            double value = 0.0;
            while (isdigit(input[pos])) {
                value = value * 10 + (input[pos] - '0');
                pos++;
            }
            if (input[pos] == '.') {
                pos++;
                double decimal_place = 1.0;
                while (isdigit(input[pos])) {
                    value = value * 10 + (input[pos] - '0');
                    decimal_place *= 10;
                    pos++;
                }
                value /= decimal_place;
            }
            return (Token){TOKEN_NUMBER, value, 0};
        }

        if (isalpha(input[pos])) {
            char identifier = input[pos++];
            return (Token){TOKEN_IDENTIFIER, 0, identifier};
        }

        switch (input[pos]) {
            case '+': pos++; return (Token){TOKEN_PLUS, 0, 0};
            case '-': pos++; return (Token){TOKEN_MINUS, 0, 0};
            case '*': pos++; return (Token){TOKEN_MULTIPLY, 0, 0};
            case '/': pos++; return (Token){TOKEN_DIVIDE, 0, 0};
            case '(': pos++; return (Token){TOKEN_LPAREN, 0, 0};
            case ')': pos++; return (Token){TOKEN_RPAREN, 0, 0};
            case '=': pos++; return (Token){TOKEN_ASSIGN, 0, 0};
            default: return (Token){TOKEN_INVALID, 0, 0};
        }
    }
    return (Token){TOKEN_END, 0, 0};
}

void eat(TokenType type) {
    if (current_token.type == type) {
        current_token = get_next_token();
    } else {
        printf("Error: Expected token type %d, got %d\n", type, current_token.type);
        exit(EXIT_FAILURE);
    }
}

double expression();
double term();
double factor();

double factor() {
    if (current_token.type == TOKEN_NUMBER) {
        double value = current_token.value;
        eat(TOKEN_NUMBER);
        return value;
    } else if (current_token.type == TOKEN_IDENTIFIER) {
        char var_name = current_token.identifier;
        eat(TOKEN_IDENTIFIER);
        return variables[var_name - 'a'];
    } else if (current_token.type == TOKEN_LPAREN) {
        eat(TOKEN_LPAREN);
        double value = expression();
        eat(TOKEN_RPAREN);
        return value;
    }
    printf("Error: Unexpected token in factor\n");
    exit(EXIT_FAILURE);
}

double term() {
    double result = factor();
    while (current_token.type == TOKEN_MULTIPLY || current_token.type == TOKEN_DIVIDE) {
        if (current_token.type == TOKEN_MULTIPLY) {
            eat(TOKEN_MULTIPLY);
            result *= factor();
        } else if (current_token.type == TOKEN_DIVIDE) {
            eat(TOKEN_DIVIDE);
            result /= factor();
        }
    }
    return result;
}

double expression() {
    double result = term();
    while (current_token.type == TOKEN_PLUS || current_token.type == TOKEN_MINUS) {
        if (current_token.type == TOKEN_PLUS) {
            eat(TOKEN_PLUS);
            result += term();
        } else if (current_token.type == TOKEN_MINUS) {
            eat(TOKEN_MINUS);
            result -= term();
        }
    }
    return result;
}

int main() {
    char buffer[256];

    while (1) {
        printf("Enter an expression ( 'exit' to quit): ");
        fgets(buffer, sizeof(buffer), stdin);
        buffer[strcspn(buffer, "\n")] = 0;
        input = buffer;

        if (strcmp(input, "exit") == 0) break;

        pos = 0;
        current_token = get_next_token();

        // Check for assignment pattern
        if (current_token.type == TOKEN_IDENTIFIER) {
            Token next_token = get_next_token();
            if (next_token.type == TOKEN_ASSIGN) {
                char var_name = current_token.identifier;
                current_token = next_token;
                eat(TOKEN_ASSIGN);
                double value = expression();
                variables[var_name - 'a'] = value;
                printf("Assigned %c = %.2f\n", var_name, value);
                continue;
            } else {

                pos = 0;
                current_token = get_next_token();
            }
        }

        // Parse as expression
        double result = expression();
        if (current_token.type != TOKEN_END) {
            printf("Error: Unexpected token at the end\n");
            continue;
        }
        printf("Result: %.2f\n", result);
    }
    return EXIT_SUCCESS;
}
