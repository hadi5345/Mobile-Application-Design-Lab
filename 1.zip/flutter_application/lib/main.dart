import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<StatefulWidget> createState() {
    return _StateMyApp();
  }
}

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Calculator (TAM)',
      home: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.blue,
          title: Text("Calculator (TAM)"),
          actions: [IconButton(onPressed: () {}, icon: Icon(Icons.search))],
        ),
        body: Center(
          child: Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/meem.jpg'),
                fit: BoxFit.cover,
              ),
            ),
            padding: EdgeInsets.all(20.0),
            margin: EdgeInsets.all(20.0),
            child: Column(
              children: [
                TextField(
                  decoration: InputDecoration(hintText: "Enter First Number"),
                  onChanged: (value) {
                    num1 = value;
                  },
                  keyboardType: TextInputType.number,
                ),
                SizedBox(height: 20.0),
                TextField(
                  decoration: InputDecoration(hintText: "Enter Second Number"),
                  onChanged: (value) {
                    num2 = value;
                  },
                  keyboardType: TextInputType.number,
                ),
                SizedBox(height: 20.0),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ElevatedButton(
                      onPressed: () => calculate('ADD'),
                      child: Text('ADD'),
                    ),
                    SizedBox(width: 10),
                    ElevatedButton(
                      onPressed: () => calculate('SUB'),
                      child: Text('SUB'),
                    ),
                    SizedBox(width: 10),
                    ElevatedButton(
                      onPressed: () => calculate('MUL'),
                      child: Text('MUL'),
                    ),
                    SizedBox(width: 10),
                    ElevatedButton(
                      onPressed: () => calculate('DIV'),
                      child: Text('DIV'),
                    ),
                  ],
                ),
                SizedBox(height: 20.0),
                Text(
                  'The Answer is: $result',
                  style: TextStyle(fontSize: 30.0),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
